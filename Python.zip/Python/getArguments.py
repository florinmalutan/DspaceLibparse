import sys


class GetArguments:
    filepath = ''
    description = True
    desciprtionLevel = 10

    def str_to_bool(self, s):
        if s == 'True' or s == 'true' :
            return True
        elif s == 'False' or s == 'false':
            return False
        else:
            raise ValueError

    def getArgv(self):
        try:
            self.filepath = sys.argv[1]
            # print(self.filepath)
        except:
            print('First argument must be the path to the file!!!')
        try:
            self.description = self.str_to_bool(sys.argv[2])
            # print(self.description)
        except:
            print('Second argument must be True or False!!!')
        try:
            self.descriptionLevel = int(sys.argv[3])
            # print(self.descriptionLevel)
        except:
            print('Third argument must be an integer eg 1,2,3,4 !!!')

    