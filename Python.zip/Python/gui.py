import tkinter as tk

def prints():
    print("buttton pressed")

class GUI:
    def gui(self):
        window = tk.Tk()
        button = tk.Button(
            text="Click me!",
            width=25,
            height=5,
            bg="blue",
            fg="yellow",
            command=prints,
        )

        button.pack()
        window.mainloop()
