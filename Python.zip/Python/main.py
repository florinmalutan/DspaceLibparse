import app_functions
from getArguments import GetArguments
import sys
import parse
import gui
def main():
    if len(sys.argv) > 1:
        print('from cmd!!!')
        obj = GetArguments()
        obj.getArgv()

        filepath = obj.filepath
        description = obj.description
        descriptionLevel = obj.descriptionLevel

        obj1 = parse.Parse(filepath,description,descriptionLevel)
        obj1.parse()


    else:
        print('from gui!!!')
        filepath = "path"
        description = True
        descriptionLevel = 1
        obj1 = parse.Parse(filepath,description,descriptionLevel)
        obj1.parse()
        objg = gui.GUI()
        objg.gui()
    


if __name__ == "__main__":  
    main()

# to compile as exe