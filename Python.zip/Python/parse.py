class Parse:
    def __init__(self,filepath,description,descriptionLevel):
        self.filepath = filepath
        self.description = description
        self.descriptionLevel = descriptionLevel

    def parse(self):
        print(f'Parsing the file using arg: ',self.filepath, self.description, self.descriptionLevel)
