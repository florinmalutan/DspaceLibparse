import sys

print('salut')
print(sys.argv[1])
print('salut')